<?php /** * Header default */ use Tutor\Ecommerce\CartController; use Tutor_Starter\Traits\Header_Components; /** * For php8.1&8.2 compatibility */ class Header_COMP { use Header_Components; } $obj = new Header_COMP(); ?>
<header class="header-default">
  <!-- .navbar .navbar-center .navbar-right .has-search-field .full-width -->
    <nav class="navBar">
    <a href="/" class="logoHome">
      <strong>Belleza del Ser</strong>
    </a>

    <ul class="menuDiv">
      <li class="menu-item has-submenu">
        <a href="https://institutovalencia.com.ar/tienda/sesiones/">Sesiones</a>
        <ul class="submenu">
          <li><a href="/sesiones/reiki">Reiki</a></li>
          <li><a href="/sesiones/registros-akashicos">Registros Akáshicos</a></li>
          <li><a href="/sesiones/coaching">Coaching</a></li>
        </ul>
      </li>

      <li><a href="/tienda/tienda">Cursos</a></li>

      <li class="menu-item has-submenu">
        <a href="/armonizaciones">Armonizaciones</a>
        <ul class="submenu">
          <li><a href="/armonizaciones/capsulas">Cápsulas</a></li>
          <li><a href="/armonizaciones/ebooks">eBooks</a></li>
        </ul>
      </li>

      <li><a href="/sobre-mi">Sobre mí</a></li>
      <li><a href="/contacto">Contacto</a></li>
    </ul>
  </nav>
</header>
