<?php wp_footer(); ?>
<footer class="footerBar">
  <div class="contentFooter">
    <div class="navNewsletter">
      <div class="navFooter">
        <div class="navFooterBar">
          <h3>
            <strong>Belleza del Ser</strong>
          </h3>
          <div class="menuFooterDiv">
            <a href="#">Home</a>
            <a href="#">Cursos</a>
            <a href="#">Sobre mi</a>
            <a href="#">Contacto</a>
          </div>
        </div>
      </div>
      <div class="newsletterFooter">
        <div class="textNwsletter">
          <h4>Newsletter</h4>
          <p>
            Un recordatorio de luz y sanación en tu bandeja de entrada. Sumate a
            la comunidad.
          </p>
        </div>
        <div class="formNewsletter">
          <input type="text" placeholder="Email" />
        </div>
      </div>
    </div>
    <div class="contactFooter">
      <div class="contact">
        <a href="#">
            <i class="fa-solid fa-envelope"></i>
          contacto@ejemplo.com
        </a>
        <a href="#">
            <i class="fa-solid fa-phone"></i>
          +34 000 000000
        </a>
        <a href="#">
            <i class="fa-solid fa-location-dot"></i>
          Ubicación, Ejemplo
        </a>
      </div>
      <div class="socialMedia">
        <p>Seguime en redes</p>
        <div class="iconSocial">
          <a href="#">
            <i class="fa-brands fa-tiktok"></i>
          </a>
          <a href="#">
            <i class="fa-brands fa-instagram"></i>
          </a>
          <a href="#">
            <i class="fa-brands fa-facebook"></i>
          </a>
          <a href="#">
            <i class="fa-brands fa-youtube"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="registredFooter">
    <p>© 2025 Naty Belleza del Ser. All Rights Reserved.</p>
  </div>
</footer>