<?php
/**
 * Funciones del tema hijo BellezaDelSer Theme
 */

// 🔹 Encola estilos del tema padre e hijo
add_action( 'wp_enqueue_scripts', 'BellezaDelSer_enqueue_styles', 20 );
function BellezaDelSer_enqueue_styles() {
    // Estilos del tema padre
    wp_enqueue_style( 
        'tutorstarter-parent-style', 
        get_template_directory_uri() . '/style.css' 
    );

    // Estilos del tema hijo
    wp_enqueue_style( 
        'BellezaDelSer-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array('tutorstarter-parent-style'), // depende del padre
        filemtime( get_stylesheet_directory() . '/style.css' ) // cache-busting
    );
}

// 🔹 Quita FA4 que trae Elementor y carga FA6
add_action( 'wp_enqueue_scripts', 'BellezaDelSer_replace_fontawesome', 20 );
function BellezaDelSer_replace_fontawesome() {
    // Quita FA4 que trae Elementor
    wp_dequeue_style( 'font-awesome' );
    wp_deregister_style( 'font-awesome' );

    // Ahora carga FA6
    wp_enqueue_style( 
        'font-awesome', 
        'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css',
        array(),
        '6.5.2'
    );
}

// 🔹 Mostrar descripción corta en las cards de producto
add_action( 'woocommerce_after_shop_loop_item_title', 'belleza_del_ser_short_description', 6 );
function belleza_del_ser_short_description() {
    global $product;
    $excerpt = $product->get_short_description();
    if ( ! empty( $excerpt ) ) {
        echo '<div class="woocommerce-product-short-description">' . wp_kses_post( $excerpt ) . '</div>';
    }
}

add_action( 'woocommerce_shop_loop_item_title', 'belleza_del_ser_add_logo_above_title', 9 );
function belleza_del_ser_add_logo_above_title() {
    // Ruta del logo dentro del tema (ajustá según tu estructura)
    $logo_url = get_stylesheet_directory_uri() . '/assets/images/logo_card.png';
    
    echo '<div class="product-card-logo">
            <img src="' . esc_url($logo_url) . '" alt="Icono" />
          </div>';
}